import React from 'react'
import ReactDOM from 'react-dom/client'
import { BrowserRouter } from 'react-router-dom'
import App from './App.jsx'
import { seedIfEmpty } from './db/seed.js'
import './index.css'

seedIfEmpty().finally(() => {
  ReactDOM.createRoot(document.getElementById('root')).render(
    <BrowserRouter><App /></BrowserRouter>
  )
})
